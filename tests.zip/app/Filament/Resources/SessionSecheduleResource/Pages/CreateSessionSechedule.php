<?php

namespace App\Filament\Resources\SessionSecheduleResource\Pages;

use App\Filament\Resources\SessionSecheduleResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateSessionSechedule extends CreateRecord
{
    protected static string $resource = SessionSecheduleResource::class;
}
